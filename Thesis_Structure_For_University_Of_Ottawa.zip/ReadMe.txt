A template for Thesis (Master of Applied Science - Masc) Ottawa- Carelton Univesity, University of Ottawa, Canada
